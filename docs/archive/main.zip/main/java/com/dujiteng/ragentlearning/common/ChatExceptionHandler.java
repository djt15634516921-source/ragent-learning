package com.dujiteng.ragentlearning.common;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;

/** 处理各业务入口的预期错误；登录过滤器的错误由 SecurityConfig 返回。 */
@RestControllerAdvice
public class ChatExceptionHandler {

    @ExceptionHandler(ChatApiException.class)
    public ResponseEntity<ChatError> handleChatError(ChatApiException error) {
        return ResponseEntity.status(error.status())
                .contentType(MediaType.APPLICATION_JSON)
                .body(new ChatError(error.code(), error.getMessage()));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ChatError> handleBadJson(HttpMessageNotReadableException error) {
        return ResponseEntity.badRequest().contentType(MediaType.APPLICATION_JSON).body(new ChatError(
                "INVALID_JSON", "请检查 JSON 请求体格式，并确认字段名称正确"));
    }

    public record ChatError(String code, String message) {
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ChatError> handleOversizedFile(MaxUploadSizeExceededException error) {
        return ResponseEntity.status(413).contentType(MediaType.APPLICATION_JSON)
                .body(new ChatError("FILE_TOO_LARGE", "单个文件不能超过 10 MB"));
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<ChatError> handleMultipart(MultipartException error) {
        return ResponseEntity.badRequest().contentType(MediaType.APPLICATION_JSON)
                .body(new ChatError("INVALID_UPLOAD", "文件请求格式不正确，请重新选择文件上传"));
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ChatError> handleInvalidId(MethodArgumentTypeMismatchException error) {
        return ResponseEntity.badRequest().contentType(MediaType.APPLICATION_JSON)
                .body(new ChatError("INVALID_PARAMETER", "请使用有效的数字编号"));
    }
}
