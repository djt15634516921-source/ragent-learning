package com.dujiteng.ragentlearning.knowledge;

import com.dujiteng.ragentlearning.common.ChatApiException;
import java.time.Instant;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/** 知识库拥有用户；文档通过所属知识库确定访问权限。 */
@Repository
public class KnowledgeRepository {
    private static final RowMapper<KnowledgeBaseView> BASE = (rs, row) -> new KnowledgeBaseView(
            rs.getLong("id"), rs.getString("name"), rs.getString("description"),
            rs.getTimestamp("created_at").toInstant());
    private static final RowMapper<DocumentRecord> DOCUMENT = (rs, row) -> new DocumentRecord(
            new DocumentView(rs.getLong("id"), rs.getLong("knowledge_base_id"),
                    rs.getString("original_filename"), rs.getString("file_type"), rs.getLong("file_size"),
                    rs.getString("status"), rs.getTimestamp("created_at").toInstant()),
            rs.getString("storage_key"));
    private final JdbcTemplate jdbc;

    public KnowledgeRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public KnowledgeBaseView create(long userId, String name, String description) {
        return jdbc.queryForObject("""
                INSERT INTO knowledge_base (user_id, name, description) VALUES (?, ?, ?)
                RETURNING id, name, description, created_at
                """, BASE, userId, name, description);
    }

    public List<KnowledgeBaseView> list(long userId) {
        return jdbc.query("""
                SELECT id, name, description, created_at FROM knowledge_base
                WHERE user_id = ? ORDER BY id DESC
                """, BASE, userId);
    }

    public void requireOwner(long userId, long knowledgeBaseId) {
        if (jdbc.query("SELECT id FROM knowledge_base WHERE id = ? AND user_id = ?",
                (rs, row) -> rs.getLong("id"), knowledgeBaseId, userId).isEmpty()) {
            throw new ChatApiException(404, "KNOWLEDGE_BASE_NOT_FOUND", "知识库不存在或不属于当前用户");
        }
    }

    public DocumentView createDocument(long userId, long knowledgeBaseId, String filename,
                                       String fileType, long size, String storageKey) {
        // 写入本身也带归属条件，不能只依赖页面选中的知识库。
        var rows = jdbc.query("""
                INSERT INTO knowledge_document
                    (knowledge_base_id, original_filename, file_type, file_size, storage_key)
                SELECT id, ?, ?, ?, ? FROM knowledge_base WHERE id = ? AND user_id = ?
                RETURNING *
                """, DOCUMENT, filename, fileType, size, storageKey, knowledgeBaseId, userId);
        if (rows.isEmpty()) {
            throw new ChatApiException(404, "KNOWLEDGE_BASE_NOT_FOUND", "知识库不存在或不属于当前用户");
        }
        return rows.get(0).view();
    }

    public List<DocumentView> listDocuments(long userId, long knowledgeBaseId) {
        requireOwner(userId, knowledgeBaseId);
        return jdbc.query("""
                SELECT d.* FROM knowledge_document d
                JOIN knowledge_base k ON k.id = d.knowledge_base_id
                WHERE k.id = ? AND k.user_id = ? ORDER BY d.id DESC
                """, DOCUMENT, knowledgeBaseId, userId).stream().map(DocumentRecord::view).toList();
    }

    public DocumentRecord findDocument(long userId, long knowledgeBaseId, long documentId) {
        var rows = jdbc.query("""
                SELECT d.* FROM knowledge_document d
                JOIN knowledge_base k ON k.id = d.knowledge_base_id
                WHERE d.id = ? AND k.id = ? AND k.user_id = ?
                """, DOCUMENT, documentId, knowledgeBaseId, userId);
        if (rows.isEmpty()) {
            throw new ChatApiException(404, "DOCUMENT_NOT_FOUND", "文档不存在或不属于当前用户");
        }
        return rows.get(0);
    }

    public record KnowledgeBaseView(long id, String name, String description, Instant createdAt) { }
    public record DocumentView(long id, long knowledgeBaseId, String filename, String fileType,
                               long size, String status, Instant createdAt) { }
    public record DocumentRecord(DocumentView view, String storageKey) { }
}
