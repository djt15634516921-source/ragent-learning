package com.dujiteng.ragentlearning.knowledge;

import com.dujiteng.ragentlearning.knowledge.KnowledgeRepository.DocumentView;
import com.dujiteng.ragentlearning.knowledge.KnowledgeRepository.KnowledgeBaseView;
import com.dujiteng.ragentlearning.system.auth.LoginUser;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.springframework.core.io.Resource;
import org.springframework.http.CacheControl;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/knowledge-bases")
public class KnowledgeController {
    private final KnowledgeService service;

    public KnowledgeController(KnowledgeService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public KnowledgeBaseView create(@AuthenticationPrincipal LoginUser user, @RequestBody CreateRequest request) {
        return service.create(user.userId(), request == null ? null : request.name(),
                request == null ? null : request.description());
    }

    @GetMapping
    public List<KnowledgeBaseView> list(@AuthenticationPrincipal LoginUser user) {
        return service.list(user.userId());
    }

    @GetMapping("/{knowledgeBaseId}/documents")
    public List<DocumentView> documents(@AuthenticationPrincipal LoginUser user, @PathVariable long knowledgeBaseId) {
        return service.documents(user.userId(), knowledgeBaseId);
    }

    @PostMapping(value = "/{knowledgeBaseId}/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public DocumentView upload(@AuthenticationPrincipal LoginUser user, @PathVariable long knowledgeBaseId,
                               @RequestPart(value = "file", required = false) MultipartFile file) {
        return service.upload(user.userId(), knowledgeBaseId, file);
    }

    @GetMapping("/{knowledgeBaseId}/documents/{documentId}/file")
    public ResponseEntity<Resource> download(@AuthenticationPrincipal LoginUser user,
                                            @PathVariable long knowledgeBaseId, @PathVariable long documentId) {
        var download = service.download(user.userId(), knowledgeBaseId, documentId);
        return ResponseEntity.ok().cacheControl(CacheControl.noStore())
                .contentType(MediaType.APPLICATION_OCTET_STREAM).contentLength(download.document().size())
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment()
                        .filename(download.document().filename(), StandardCharsets.UTF_8).build().toString())
                .body(download.resource());
    }

    public record CreateRequest(String name, String description) { }
}
